import React from 'react';
import { ShoppingCart } from 'lucide-react';

interface ProductProps {
  id: number;
  name: string;
  price: number;
  image: string;
  unit: string;
  origin?: string;
  onAddToCart: () => void;
}

export default function ProductCard({ name, price, image, unit, origin, onAddToCart }: ProductProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('si-LK', {
      style: 'currency',
      currency: 'LKR',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price);
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-[1.02]">
      <div className="relative aspect-square overflow-hidden bg-gray-50">
        <img
          src={image}
          alt={name}
          className="object-cover w-full h-full hover:scale-110 transition-transform duration-300"
        />
        {origin && (
          <span className="absolute top-2 left-2 bg-green-600 text-white px-2 py-1 rounded-full text-xs font-medium">
            {origin}
          </span>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-medium text-gray-800 mb-2">{name}</h3>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-lg font-bold text-green-700">{formatPrice(price)}</p>
            <p className="text-sm text-gray-500">per {unit}</p>
          </div>
          <button
            onClick={onAddToCart}
            className="bg-green-600 hover:bg-green-700 text-white p-2 rounded-full transition-colors"
          >
            <ShoppingCart size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}