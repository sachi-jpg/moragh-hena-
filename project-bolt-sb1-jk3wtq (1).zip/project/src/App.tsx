import React, { useState } from 'react';
import { Leaf, Search, ShoppingCart } from 'lucide-react';
import { Toaster } from 'react-hot-toast';
import ProductCard from './components/ProductCard';
import CategoryFilter from './components/CategoryFilter';
import OrderModal from './components/OrderModal';

const categories = [
  'All Vegetables',
  'Organic',
  'Local',
  'Leafy Greens',
  'Root Vegetables',
  'Herbs',
];

const products = [
  {
    id: 1,
    name: 'Organic Baby Spinach',
    price: 450,
    unit: '250g',
    image: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=800&q=80',
    origin: 'Organic',
  },
  {
    id: 2,
    name: 'Fresh Carrots',
    price: 380,
    unit: 'bunch',
    image: 'https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?w=800&q=80',
    origin: 'Local',
  },
  {
    id: 3,
    name: 'Cherry Tomatoes',
    price: 550,
    unit: '500g',
    image: 'https://images.unsplash.com/photo-1546094096-0df4bcaaa337?w=800&q=80',
  },
  {
    id: 4,
    name: 'Fresh Basil',
    price: 280,
    unit: 'bunch',
    image: 'https://images.unsplash.com/photo-1618164435735-413d3b066c9a?w=800&q=80',
    origin: 'Local',
  },
  {
    id: 5,
    name: 'Sweet Potato',
    price: 420,
    unit: 'kg',
    image: 'https://images.unsplash.com/photo-1596097635121-14b63b7a0c19?w=800&q=80',
  },
  {
    id: 6,
    name: 'Organic Kale',
    price: 380,
    unit: 'bunch',
    image: 'https://images.unsplash.com/photo-1524179091875-bf99a9a6af57?w=800&q=80',
    origin: 'Organic',
  },
];

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  unit: string;
}

function App() {
  const [selectedCategory, setSelectedCategory] = useState('All Vegetables');
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);

  const filteredProducts = products.filter((product) => {
    const matchesCategory =
      selectedCategory === 'All Vegetables' ||
      product.origin === selectedCategory ||
      (selectedCategory === 'Local' && product.origin === 'Local') ||
      (selectedCategory === 'Organic' && product.origin === 'Organic');

    const matchesSearch = product.name
      .toLowerCase()
      .includes(searchQuery.toLowerCase());

    return matchesCategory && matchesSearch;
  });

  const addToCart = (productId: number) => {
    const product = products.find((p) => p.id === productId);
    if (!product) return;

    setCart((currentCart) => {
      const existingItem = currentCart.find((item) => item.id === productId);
      if (existingItem) {
        return currentCart.map((item) =>
          item.id === productId
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...currentCart, { ...product, quantity: 1 }];
    });
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const clearCart = () => {
    setCart([]);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster position="top-center" />
      
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Leaf className="h-8 w-8 text-green-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">මොරගහ හෙන</h1>
                <p className="text-sm text-gray-500">Fresh Vegetables Market</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search vegetables..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-full w-64 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
              <button
                onClick={() => setIsOrderModalOpen(true)}
                className="relative bg-green-600 text-white p-2 rounded-full hover:bg-green-700 transition-colors"
              >
                <ShoppingCart size={24} />
                {cart.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                    {cart.reduce((sum, item) => sum + item.quantity, 0)}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Fresh Vegetables</h2>
          <p className="text-gray-600">
            Discover our selection of fresh, locally-sourced, and organic vegetables.
          </p>
        </div>

        <CategoryFilter
          categories={categories}
          selected={selectedCategory}
          onSelect={setSelectedCategory}
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              {...product}
              onAddToCart={() => addToCart(product.id)}
            />
          ))}
        </div>
      </main>

      <OrderModal
        isOpen={isOrderModalOpen}
        onClose={() => setIsOrderModalOpen(false)}
        cart={cart}
        total={cartTotal}
        clearCart={clearCart}
      />
    </div>
  );
}

export default App;